# Coherence Sample Dataset

Exported from the Coherence AI learning app on 2026-10-22.

## Files
- `lessons.csv` — one row per lesson (title, source, YouTube id, duration, summary)
- `topic_markers.csv` — topic sections within each lesson, keyed by `lesson_id`, with start time in seconds
- `transcript_chunks.csv` — timestamped transcript segments, keyed by `lesson_id`
- `quiz_questions.csv` — multiple-choice questions, keyed by `lesson_id` and `topic_marker_id`; options are separated by ` | ` and `answer_index` is the 0-based correct option
- `coherence_dataset.json` — all of the above in a single JSON file

## Notes
- The seeded lesson "Quantum mechanics as a framework" uses an approximate, unverified transcript written for demonstration; it is not the official MIT caption file.
- "Testing linear operators" is a small lesson imported through the app's own lesson-import feature during testing.
